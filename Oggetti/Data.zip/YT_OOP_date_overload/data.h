#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED
#include <string>
#include <ctime>

class Data
{
  public:
    //costruttori
    Data();
    Data(int gg, int mm, int aa);
    Data(int gg, int mm); //anno == anno corrente
    Data(int gg); //anno e mese == quelli correnti

    Data(const std::string d); //"07-09-2016"


    //osservatori
    std::string formato_breve();
    int get_giorno() const {return giorno;}
    int get_mese() const {return mese;}
    int get_anno() const {return anno;}


    //overload operatori standard
    bool operator==(const Data&);
    bool operator<(const Data&);
    bool operator>(const Data&);
    Data operator++(int);

    //altri
    static tm* data_corrente();
    bool valida(int gg, int mm, int aa);
    bool uguale_a(Data altra);
    static bool bisestile(int);
    static int giorni_mese(int, int);



   private:
    //int giorno = 1, mese=1, anno=1970;
    int giorno {oggi->tm_mday};
    int mese {oggi->tm_mon+1};
    int anno {oggi->tm_year+1900};
    static tm* oggi;
};


#endif // DATA_H_INCLUDED
